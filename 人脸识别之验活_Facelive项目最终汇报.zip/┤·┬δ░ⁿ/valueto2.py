# coding:utf-8
import pylab
import imageio
import face_recognition
from PIL import Image,ImageDraw
import numpy as np
#注释的代码执行一次就好，以后都会默认下载完成
#imageio.plugins.ffmpeg.download()
import skimage
import numpy as np
from PIL import Image
def geteye(image):
    face_locations = face_recognition.face_locations(image, number_of_times_to_upsample=3)
    face_landmarks_list = face_recognition.face_landmarks(image, face_locations)
    print face_landmarks_list

    print ("I found{} faces in this photography".format(len(face_landmarks_list)))

    for face_landmarks in face_landmarks_list:
        facial_features = ['chin', 'left_eyebrow', 'right_eyebrow', 'nose_bridge',
                           'nose_tip', 'left_eye', 'right_eye', 'top_lip', 'bottom_lip']
        for facial_feature in facial_features:
            print ("the{} in this face has the follwing points:{}".format(
                facial_feature, face_landmarks[facial_feature]))

        pil_image = Image.fromarray(image)
        d = ImageDraw.Draw(pil_image)

        for facial_feature in facial_features:
            d.line(face_landmarks[facial_feature], width=1)
            if (facial_feature == 'right_eye'):
                part_image_array = image[np.min(face_landmarks[facial_feature], 0)[1]:
                np.max(face_landmarks[facial_feature], 0)[1],
                                   np.min(face_landmarks[facial_feature], 0)[0]+16:
                                   np.max(face_landmarks[facial_feature], 0)[0]-16]
                print np.max(face_landmarks[facial_feature],0)[0],np.min(face_landmarks[facial_feature],0)[0]
                print np.max(face_landmarks[facial_feature],0)[1], np.min(face_landmarks[facial_feature],0)[1]

                d.line(face_landmarks[facial_feature], width=1)
                part_image = Image.fromarray(part_image_array)
                #二值化处理代码
                im_arr = np.array(part_image.convert('L'))
                print im_arr
                for x in range(len(im_arr)):
                    for y in range(len(im_arr[x])):
                        im_arr[x, y] = int(im_arr[x, y] >= 90)
                print im_arr
                part_image=Image.fromarray(im_arr)
                part_image.show()
        pil_image.show()
#视频的绝对路径
filename = 'video/31.mp4'
#可以选择解码工具'ffmpeg'
vid = imageio.get_reader(filename,'ffmpeg')

temp=15;
for num,im in enumerate(vid):
    #image的类型是mageio.core.util.Image可用下面这一注释行转换为arrary
    print im.mean()
    image = skimage.img_as_float(im).astype(np.float64)

    if num==temp:
        temp +=1;
        fig = pylab.figure()
        fig.suptitle('image #{}'.format(num), fontsize=20)
        #pylab.imshow(im)
        #righteye=geteye(im)
        geteye(im)
        #righteye.show()
    if num==22 : break;

#pylab.show()